# GPIO Pin Map — ESP32-S3-DevKitC-1 (N16R8)

> 本文件為 esp32s3-barcode-scanner 專案的 GPIO 完整分配總表。
> 對應原始碼：`src/config/pinout.h`

## 總覽

| 類別 | 已用數量 | GPIO |
|------|---------|------|
| Camera (OV2640) | 14 | 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 15, 16, 17, 18 |
| TFT LCD (SPI2) | 6 | 35, 36, 37, 38, 39, 40 |
| SD Card (SPI3) | 4 | 1, 2, 41, 42 |
| Joystick (5-way) | 5 | 3, 21, 33, 34, 47 |
| Misc (Buzzer/LED/Button) | 3 | 0, 14, 48 |
| **已使用合計** | **32** | — |
| 不可用 (硬體保留) | 11 | 19, 20, 26–32, 43, 44 |
| **空閒可用** | **2** | 45, 46 |

---

## Camera — OV2640

| Signal | GPIO | 備註 |
|--------|------|------|
| XCLK | 15 | 20 MHz clock output |
| SIOD (SDA) | 4 | SCCB I²C data |
| SIOC (SCL) | 5 | SCCB I²C clock |
| VSYNC | 6 | |
| HREF | 7 | |
| PCLK | 13 | Pixel clock input |
| D0 | 11 | |
| D1 | 9 | |
| D2 | 8 | |
| D3 | 10 | |
| D4 | 12 | |
| D5 | 18 | |
| D6 | 17 | |
| D7 | 16 | |
| PWDN | -1 | 未接 (tie to GND) |
| RESET | -1 | 未接 (software reset) |

---

## TFT LCD — SPI2 (HSPI)

| Signal | GPIO | 備註 |
|--------|------|------|
| MOSI | 35 | |
| SCLK | 36 | |
| CS | 37 | |
| DC | 38 | |
| RST | 39 | |
| BL (Backlight) | 40 | PWM (LEDC CH0) |

- SPI Clock: 40 MHz
- 尺寸: 2.8" TFT
- 解析度: 240×RGB×320
- 驅動 IC: ILI9341
- GUI: LVGL v8.4
- 輸入方式: 按鍵導航 (Key navigation)，不使用觸控

> 模組自帶 XPT2046 觸控及 SD 卡槽，本專案觸控未啟用。

---

## SD Card — SPI3 (VSPI)

> SD Card 模組整合於 2.8" TFT LCD 模組背面

| Signal | GPIO | 備註 |
|--------|------|------|
| MISO | 41 | |
| MOSI | 42 | |
| SCLK | 2 | |
| CS | 1 | |

- SPI Clock: 20 MHz

---

## Joystick — 5 方向導航搖桿

| 方向 | GPIO | LVGL Key | 備註 |
|------|------|----------|------|
| UP | 3 | LV_KEY_UP | INPUT_PULLUP, active LOW |
| DOWN | 21 | LV_KEY_DOWN | INPUT_PULLUP, active LOW |
| LEFT | 33 | LV_KEY_LEFT | INPUT_PULLUP, active LOW |
| RIGHT | 34 | LV_KEY_RIGHT | INPUT_PULLUP, active LOW |
| PRESS (確認) | 47 | LV_KEY_ENTER | INPUT_PULLUP, active LOW |

- 類型：數位 5 方向搖桿（Nav switch / 5-way tactile）
- 接法：各方向接 GPIO + GND，使用內部上拉電阻
- 防抖：軟體 debounce 20ms

---

## Misc

| 功能 | GPIO | 備註 |
|------|------|------|
| Buzzer | 14 | PWM (LEDC CH1), 2700 Hz |
| Status LED | 48 | Onboard RGB/GPIO LED |
| User Button | 0 | BOOT button (LV_KEY_ESC) |

---

## 不可用 GPIO（硬體保留）

| GPIO | 用途 |
|------|------|
| 19, 20 | USB OTG (D−, D+) |
| 26–32 | PSRAM Octal SPI (N16R8 內部) |
| 43 | UART0 TXD (Serial debug) |
| 44 | UART0 RXD (Serial debug) |

---

## 空閒可用 GPIO

| GPIO | 注意事項 |
|------|----------|
| 45 | ⚠️ Strapping pin (VDD_SPI voltage) |
| 46 | ⚠️ Strapping pin (ROM log) |

> GPIO 45/46 為 strapping pin，開機時電平會影響啟動行為，作為一般 I/O 使用時需確認外部電路不干擾啟動。

---

## GPIO 全表 (0–48)

| GPIO | 分配 | 模組 |
|------|------|------|
| 0 | User Button (BOOT) | Misc |
| 1 | SD CS | SD Card |
| 2 | SD SCLK | SD Card |
| 3 | Joystick UP | Joystick |
| 4 | CAM SIOD (SDA) | Camera |
| 5 | CAM SIOC (SCL) | Camera |
| 6 | CAM VSYNC | Camera |
| 7 | CAM HREF | Camera |
| 8 | CAM D2 | Camera |
| 9 | CAM D1 | Camera |
| 10 | CAM D3 | Camera |
| 11 | CAM D0 | Camera |
| 12 | CAM D4 | Camera |
| 13 | CAM PCLK | Camera |
| 14 | Buzzer | Misc |
| 15 | CAM XCLK | Camera |
| 16 | CAM D7 | Camera |
| 17 | CAM D6 | Camera |
| 18 | CAM D5 | Camera |
| 19 | ✖ USB OTG D− | 保留 |
| 20 | ✖ USB OTG D+ | 保留 |
| 21 | Joystick DOWN | Joystick |
| 22–25 | (不存在於 ESP32-S3) | — |
| 26–32 | ✖ PSRAM | 保留 |
| 33 | Joystick LEFT | Joystick |
| 34 | Joystick RIGHT | Joystick |
| 35 | TFT MOSI | TFT LCD |
| 36 | TFT SCLK | TFT LCD |
| 37 | TFT CS | TFT LCD |
| 38 | TFT DC | TFT LCD |
| 39 | TFT RST | TFT LCD |
| 40 | TFT BL | TFT LCD |
| 41 | SD MISO | SD Card |
| 42 | SD MOSI | SD Card |
| 43 | ✖ UART0 TXD | 保留 |
| 44 | ✖ UART0 RXD | 保留 |
| 45 | — | **空閒** ⚠️ |
| 46 | — | **空閒** ⚠️ |
| 47 | Joystick PRESS | Joystick |
| 48 | Status LED | Misc |
