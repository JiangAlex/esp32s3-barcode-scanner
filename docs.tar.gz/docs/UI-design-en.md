# UI Design Document — ESP32-S3 Barcode Scanner

> LVGL v8.4 + ILI9341 (240×320) + Joystick Key Navigation
> UI supports real-time Chinese/English language switching (i18n)

---

## System Overview

### Hardware Configuration

| Item | Specification |
|------|--------------|
| Display | 2.8" TFT LCD 240×RGB×320 |
| Driver IC | ILI9341 |
| GUI Framework | LVGL v8.4 |
| Input Method | 5-way joystick + BOOT button |
| Touch | XPT2046 (on-module, **not used**) |
| Color Depth | 16-bit RGB565 |
| Orientation | Portrait |

### Feature Scope

| Feature | ESP32 Responsibility | Description |
|---------|---------------------|-------------|
| Scan & Query | ✅ | Scan barcode → query warehouse DB → display result |
| Input Mode (BLE HID) | ✅ | Emulate BT keyboard, output scan value to cursor |
| Input Mode (MQTT) | ✅ | Push scan value to Web UI field |
| Inventory Mode | ✅ | Continuous scan → accumulate list → batch upload |
| Photo Recognition | ✅ | Take photo → HTTP POST to server → AI OCR |
| Work Log | ✅ | Auto-record all operations to SD card |
| Offline Cache | ✅ | Auto-cache when disconnected → sync on reconnect |
| Settings | ✅ | WiFi / MQTT / BLE / Language / Brightness / Volume |
| Create New Item (CJK) | ❌ | Handled by Server Web UI |

---

## Input Method

### Joystick Key Mapping

| Direction | GPIO | LVGL Key Code | Function |
|-----------|------|---------------|----------|
| Up | 3 | LV_KEY_UP | Menu up / list scroll |
| Down | 21 | LV_KEY_DOWN | Menu down / list scroll |
| Left | 33 | LV_KEY_LEFT | Back / cursor left |
| Right | 34 | LV_KEY_RIGHT | Enter sub-item / cursor right |
| Press | 47 | LV_KEY_ENTER | Confirm / select |
| BOOT key | 0 | LV_KEY_ESC | Cancel / return to home |

### Navigation Logic

- **← = Back** to previous page
- **→ = Enter** sub-page
- **Press = Confirm** action
- **BOOT long press = Home**

---

## Chinese Font Scheme

### Font Configuration

| Usage | Size | Character Set | Estimated Size |
|-------|------|---------------|----------------|
| Title / Item name | 20px | Common 3000 CJK + ASCII | ~180KB |
| Body / Spec | 16px | Common 3000 CJK + ASCII | ~120KB |
| Status bar / Aux | 12px | ASCII + Basic 500 CJK | ~40KB |

- Anti-aliasing: 4-bit (bpp=4)
- Encoding: UTF-8
- Storage: Compiled into Flash (16MB sufficient)
- Tool: `lv_font_conv`

---

## i18n Multilingual

### Implementation

String table switching, no recompilation needed:

```c
// Chinese
"scan"    → "掃描"
"photo"   → "拍照辨識"
"settings"→ "設定"
"back"    → "返回"

// English
"scan"    → "Scan"
"photo"   → "Photo AI"
"settings"→ "Settings"
"back"    → "Back"
```

Language switch in Settings page, takes effect immediately.

---

## Page Structure

```
Home (3-item list)
 ├── Scan  →  Live Preview (↑↓ switch mode, ←→ switch channel)
 │              ├── 🔍 Query Mode → Query Result page
 │              ├── 📤 Input Mode
 │              │     ├── ⌨️ BLE HID → Emulate keyboard output
 │              │     └── 🌐 MQTT → Push to Web UI
 │              └── 📋 Inventory Mode → Inventory List → Upload
 ├── Photo AI  →  Live Preview  →  Capture Confirm  →  Upload
 └── Settings  →  WiFi / MQTT / BLE / Language / Brightness / Volume / Log
```

---

## Shared Element — Status Bar

```
┌────────────────────── 240px ──────────────────────┐
│ [📶 WiFi] [🔗 MQTT] [⌨️ BLE]          [14:30]   │ ← 24px
├───────────────────────────────────────────────────┤
│                                                   │
│                 Page Content Area                  │ ← 296px
│                 (240 × 296)                       │
│                                                   │
└───────────────────────────────────────────────────┘
```

| Icon | Meaning |
|------|---------|
| 📶 | WiFi connected |
| 🔗 | MQTT connected |
| ⌨️ | BLE HID paired |
| ↑3 | Offline cache pending sync |

---

## Page Designs

### 1. Home — Main Menu

```
┌───────────────────────────────────────┐
│ 📶  🔗  ⌨️                    14:30  │
├───────────────────────────────────────┤
│                                       │
│     ▶ 📷  Scan                        │  ← focused
│                                       │
│       📸  Photo AI                    │
│                                       │
│       ⚙️  Settings                    │
│                                       │
└───────────────────────────────────────┘
```

- Vertical list, ↑↓ to select
- Press / → = enter
- Clean and intuitive

---

### 2. Scan Page — Query Mode

```
┌───────────────────────────────────────┐
│ ◀ Scan            [🔍Query/📤Input/📋Inv] │
├───────────────────────────────────────┤
│                                       │
│  ┌─────────────────────────────────┐  │
│  │                                 │  │
│  │       Camera Preview            │  │
│  │       (240 × 180 grayscale)     │  │  180px
│  │          ┌────────┐            │  │
│  │          │ Focus  │            │  │
│  │          └────────┘            │  │
│  └─────────────────────────────────┘  │
│                                       │
│  Mode: 🔍 Query                       │
│  Status: Waiting for scan...          │
│  ───────────────────────────────────  │
│  [Press to scan]    [↑↓ Switch mode]  │
└───────────────────────────────────────┘
```

- ↑↓ = switch mode (Query / Input / Inventory)
- Press = trigger scan
- ← = return to home
- Scan success → buzzer + navigate to result page

---

### 3. Scan Page — Input Mode

```
┌───────────────────────────────────────┐
│ ◀ Scan            [🔍Query/📤Input/📋Inv] │
├───────────────────────────────────────┤
│                                       │
│  ┌─────────────────────────────────┐  │
│  │       Camera Preview            │  │  180px
│  └─────────────────────────────────┘  │
│                                       │
│  Mode: 📤 Input                       │
│  Channel: ⌨️ BLE HID   [←→ Switch]   │
│  Status: Paired ✓ (MacBook Pro)       │
│  ───────────────────────────────────  │
│  Last: 4710088123456 ✓ Sent           │
└───────────────────────────────────────┘
```

- ←→ = switch channel (BLE HID / MQTT)
- Press = scan and send
- Confirmation shown after each scan

**BLE not paired:**
```
│  Channel: ⌨️ BLE HID                  │
│  Status: ⚠️ Not paired (search SoftSnail) │
```

**MQTT channel:**
```
│  Channel: 🌐 MQTT → Web UI            │
│  Status: MQTT Connected ✓             │
│  Last: 4710088123456 ✓ Sent           │
```

---

### 4. Scan Page — Inventory Mode

```
┌───────────────────────────────────────┐
│ ◀ Scan            [🔍Query/📤Input/📋Inv] │
├───────────────────────────────────────┤
│                                       │
│  ┌─────────────────────────────────┐  │
│  │       Camera Preview            │  │
│  │       (Continuous scanning)     │  │  150px
│  └─────────────────────────────────┘  │
│                                       │
│  Mode: 📋 Inventory        [Active🔴] │
│  Scanned: 12 items                    │
│  ───────────────────────────────────  │
│  Latest: 4710088123456 電阻 10kΩ      │
│  Prev:   8801234567890 IC NE555       │
│  ───────────────────────────────────  │
│  [Pause]    [View List]    [Upload]   │
└───────────────────────────────────────┘
```

- Auto continuous scan, accumulate on each hit
- Duplicate barcode → quantity +1
- Press "View List" → inventory list page
- Press "Upload" → confirmation dialog → batch upload to server

---

### 5. Inventory List Page

```
┌───────────────────────────────────────┐
│ ◀ Inventory List              12 items │
├───────────────────────────────────────┤
│                                       │
│  # │ Barcode        │ Name    │ Qty  │
│  ──┼────────────────┼─────────┼───── │
│  1 │ 4710088123456  │ 電阻10k │  3   │
│  2 │ 8801234567890  │ NE555   │  1   │
│  3 │ 2345678901234  │ 電容100n│  5   │
│  4 │ 6901234567890  │ LED Red │  2   │
│  ...                                  │
│                                       │
│  [Back to Scan]        [Upload All]   │
└───────────────────────────────────────┘
```

- ↑↓ browse list
- Press "Upload All" → batch upload to server

---

### 6. Query Result Page

```
┌───────────────────────────────────────┐
│ ◀ Query Result                        │
├───────────────────────────────────────┤
│                                       │
│  Barcode: 4710088123456               │
│  ───────────────────────────────────  │
│  Name: 電阻 10kΩ                      │  ← 20px CJK
│  Spec: 0805 1/8W                      │
│  Qty:  500                            │
│  Location: A-01-03                    │  ← highlighted
│  Supplier: 大毅科技                    │
│  Date In: 2026-07-20                  │
│  ───────────────────────────────────  │
│  [Re-scan]              [Save Log]    │
└───────────────────────────────────────┘
```

- ↑↓ scroll content
- ← return to scan page
- Not found → "Item not found, please create via Web UI"

---

### 7. Photo Recognition Page

```
┌───────────────────────────────────────┐
│ ◀ Photo AI                            │
├───────────────────────────────────────┤
│                                       │
│  ┌─────────────────────────────────┐  │
│  │                                 │  │
│  │       Camera Preview            │  │
│  │       (240 × 180)              │  │  180px
│  │                                 │  │
│  └─────────────────────────────────┘  │
│                                       │
│  Status: Previewing                   │
│  ───────────────────────────────────  │
│  [Press to capture]                   │
└───────────────────────────────────────┘
```

After capture:
```
│  ┌─────────────────────────────────┐  │
│  │       Captured photo (static)   │  │  180px
│  └─────────────────────────────────┘  │
│                                       │
│  ⏳ Uploading to server...            │
│  ───────────────────────────────────  │
│  [Retake]              [Upload]       │
```

Upload complete:
```
│  ✅ Sent. Please confirm result on Web UI │
│  [Continue]            [Home]         │
```

### Technical Specs

| Item | Spec |
|------|------|
| Capture resolution | SVGA (800×600) or UXGA (1600×1200) |
| Image format | JPEG (OV2640 hardware encoding) |
| Transfer method | HTTP POST (too large for MQTT) |
| Image size | SVGA ~30-80KB, UXGA ~80-200KB |

---

### 8. Settings Page

```
┌───────────────────────────────────────┐
│ ◀ Settings                            │
├───────────────────────────────────────┤
│                                       │
│  WiFi                                 │
│    SSID:     MyNetwork        [Edit]  │
│    Password: ********         [Edit]  │
│    Status:   Connected ✓              │
│  ──────────────────────────────────── │
│  MQTT                                 │
│    Broker:   192.168.1.100    [Edit]  │
│    Port:     1883             [Edit]  │
│    Status:   Connected ✓              │
│  ──────────────────────────────────── │
│  Bluetooth                            │
│    Status:   Connected (MacBook Pro)  │
│    Name:     SoftSnail         [Edit] │
│    Broadcast: ✅ On     [←→ Toggle]   │
│    Suffix:   Enter      [←→ Switch]  │
│  ──────────────────────────────────── │
│  Language:   English    [←→ Switch]   │
│  ──────────────────────────────────── │
│  Display                              │
│    Brightness: ████████░░  80%        │
│  ──────────────────────────────────── │
│  Audio                                │
│    Volume:   ████░░░░░░  40%          │
│  ──────────────────────────────────── │
│  [Work Log]                           │
│  Device ID:  esp32-001                │
└───────────────────────────────────────┘
```

- ↑↓ select item
- ←→ adjust slider / toggle option
- Press "Edit" → virtual keyboard (alphanumeric)
- Press "Work Log" → log page
- ← return to home

---

### 9. Virtual Keyboard Page

```
┌───────────────────────────────────────┐
│  Input                                │
├───────────────────────────────────────┤
│  ┌─────────────────────────────────┐  │
│  │ MyNetwork_5G|                   │  │  40px
│  └─────────────────────────────────┘  │
├───────────────────────────────────────┤
│  [Q][W][E][R][T][Y][U][I][O][P]      │
│  [A][S][D][F][G][H][J][K][L]         │  250px
│  [⇧][Z][X][C][V][B][N][M][⌫]        │  lv_keyboard
│  [123][ Space ][←][→][✓ Done]        │
└───────────────────────────────────────┘
```

- Alphanumeric + symbols only, no CJK input
- Joystick ↑↓←→ to navigate keys
- Press = input character
- ✓ or BOOT(ESC) = done / cancel

---

### 10. Work Log Page

```
┌───────────────────────────────────────┐
│ ◀ Work Log                2026-07-30  │
├───────────────────────────────────────┤
│                                       │
│  14:20  Scan  4710088123456  ✓ Found  │
│  14:18  Scan  8801234567890  ✓ Found  │
│  14:15  Photo  Uploaded ✓             │
│  13:50  Inventory  Done (23) ✓        │
│  13:45  Scan  0000000000000  ✗ N/A    │
│  ...                                  │
│                                       │
│  [← Prev Day]         [Next Day →]   │
└───────────────────────────────────────┘
```

- Auto-records all operations
- Stored on SD card `/sd/logs/YYYY-MM-DD.json`
- ←→ switch date

---

## LVGL Focus Management (Groups)

| Page | Group | Contains |
|------|-------|----------|
| Home | group_home | 3 list items |
| Scan | group_scan | Mode switch + channel switch + buttons |
| Inventory List | group_inventory | list items + buttons |
| Result | group_result | Scrollable content + buttons |
| Photo | group_photo | Buttons |
| Settings | group_settings | Items + sliders |
| Keyboard | group_keyboard | lv_keyboard |
| Log | group_log | Date switch + list |

### Focus Visual Style

- Focused: border highlight (accent color)
- Unfocused: normal display
- Theme: dark

---

## Offline Cache Mechanism

| Network State | Behavior |
|--------------|----------|
| Online | Real-time MQTT query / HTTP upload / BLE output |
| Offline | Scan saves to SD card queue, shows "Cached ⚡" |
| Reconnected | Auto background sync → status bar "↑3 Syncing" → done |
